# -*- coding: utf-8 -*-
"""
补跑 B-spline KAN 在 CRC 九类 与 跨域 两个设置上的对照（补 Fig.3 缺口）。
复用缓存特征，10 种子，带断点续跑。

用法：conda activate gpt2 && python bspline_kan_extra.py --seeds 10
"""
import os
import json
import argparse
import numpy as np
import torch
from scipy import stats

from bspline_kan_experiment import (BsplineKANLayer, BsplineKANBlock,
                                     build_bspline_kan_head, build_mlp_matched,
                                     train_head, set_seed, n_params, DEFAULT_SEEDS)

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CRC_FEATS = os.path.join(BASE, "KAN", "crc9_resnet50_feats.npz")
CROSS_FEATS = os.path.join(BASE, "KAN", "colon_gen_feats.npz")
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"


def train_head_no_es(head, Xtr, Ytr, Xte, Yte, epochs=15, batch_size=256):
    """不早停：训练 epochs 轮，最后在测试集评估一次（用于跨域，避免测试集泄漏）。"""
    head = head.to(DEVICE)
    tr = torch.utils.data.TensorDataset(torch.from_numpy(Xtr), torch.from_numpy(Ytr))
    te = torch.utils.data.TensorDataset(torch.from_numpy(Xte), torch.from_numpy(Yte))
    tr_dl = torch.utils.data.DataLoader(tr, batch_size=batch_size, shuffle=True)
    te_dl = torch.utils.data.DataLoader(te, batch_size=batch_size)
    opt = torch.optim.AdamW(head.parameters(), lr=1e-3, weight_decay=1e-4)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs)
    crit = torch.nn.CrossEntropyLoss(label_smoothing=0.1)
    for _ in range(epochs):
        head.train()
        for xb, yb in tr_dl:
            xb, yb = xb.to(DEVICE), yb.to(DEVICE)
            opt.zero_grad()
            loss = crit(head(xb), yb)
            loss.backward()
            opt.step()
        sched.step()
    head.eval()
    corr, tot = 0, 0
    with torch.no_grad():
        for xb, yb in te_dl:
            xb, yb = xb.to(DEVICE), yb.to(DEVICE)
            corr += (head(xb).argmax(1) == yb).sum().item()
            tot += yb.size(0)
    return corr / tot * 100


def run_setting(name, feats_path, n_cls, xte_key, yte_key, seeds, no_es=False):
    d = np.load(feats_path)
    Xtr = d["Xtr"].astype(np.float32)
    Ytr = d["Ytr"]
    Xte = d[xte_key].astype(np.float32)
    Yte = d[yte_key]
    dim = Xtr.shape[1]
    print(f"[{name}] train {Xtr.shape} | test {Xte.shape} | n_cls {n_cls}", flush=True)

    bkan = build_bspline_kan_head(dim, n_cls=n_cls)
    mm, H = build_mlp_matched(dim, n_params(bkan), n_cls=n_cls)
    print(f"  B-spline KAN {n_params(bkan):,} | matched MLP(H={H}) {n_params(mm):,}", flush=True)

    train_fn = train_head_no_es if no_es else train_head
    res_b, res_m = [], []
    for seed in seeds:
        set_seed(seed)
        res_b.append(train_fn(build_bspline_kan_head(dim, n_cls=n_cls),
                              Xtr, Ytr, Xte, Yte, batch_size=256))
        set_seed(seed)
        res_m.append(train_fn(build_mlp_matched(dim, n_params(bkan), n_cls=n_cls)[0],
                              Xtr, Ytr, Xte, Yte, batch_size=512))
        print(f"  seed {seed:>4d}: B-spline KAN {res_b[-1]:6.3f}% | MLP {res_m[-1]:6.3f}%", flush=True)

    b, m = np.array(res_b), np.array(res_m)
    t, p = stats.ttest_rel(b, m)
    F = max(b.var(ddof=1), m.var(ddof=1)) / min(b.var(ddof=1), m.var(ddof=1))
    p_f = 2 * (1 - stats.f.cdf(F, len(b) - 1, len(m) - 1))
    print(f"  => B-spline KAN {b.mean():.3f}% ± {b.std(ddof=1):.3f}% | "
          f"MLP {m.mean():.3f}% ± {m.std(ddof=1):.3f}% | diff {(b-m).mean():+.3f}% | "
          f"t={t:.2f} p={p:.4f} | F={F:.2f} p={p_f:.4f}", flush=True)
    return {"name": name, "n_cls": n_cls,
            "bspline_params": n_params(bkan), "mlp_params": n_params(mm),
            "bspline": b.tolist(), "mlp": m.tolist(),
            "diff_mean": float((b - m).mean()), "t": float(t), "p": float(p)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, default=10)
    args = ap.parse_args()
    seeds = DEFAULT_SEEDS[:args.seeds]

    partial = os.path.join(BASE, "KAN", "bspline_extra_partial.json")
    results = {}
    if os.path.exists(partial):
        with open(partial, encoding="utf-8") as f:
            results = json.load(f)
        print("加载断点（部分结果）")

    if "crc9" not in results:
        results["crc9"] = run_setting("CRC 9-class", CRC_FEATS, 9, "Xva", "Yva", seeds)
        with open(partial, "w", encoding="utf-8") as f:
            json.dump(results, f)
    if "cross" not in results:
        results["cross"] = run_setting("Cross-domain", CROSS_FEATS, 2, "Xte", "Yte", seeds, no_es=True)
        with open(partial, "w", encoding="utf-8") as f:
            json.dump(results, f)

    with open(os.path.join(BASE, "KAN", "bspline_extra_result.json"), "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print("\n结果已保存 bspline_extra_result.json")


if __name__ == "__main__":
    main()

# -*- coding: utf-8 -*-
"""
生成 Graphical Abstract（图文摘要，CBM 要求宽 ≥1328px、5×13cm 可读）。
核心信息：KAN 分类头的性能增益取决于基函数，而非架构。
用法：conda activate gpt2 && python gen_graphical_abstract.py
"""
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(BASE, "paper_figures")
os.makedirs(OUT, exist_ok=True)

plt.rcParams["font.sans-serif"] = ["Arial", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False

# 参数扫描数据
mlp_p = [139781, 295941, 657413, 1643141, 2758661, 4202501]
mlp_a = [98.463, 98.935, 99.113, 99.285, 99.344, 99.298]

fig, ax = plt.subplots(figsize=(13.28, 4.6), dpi=150)  # 约 1992×690 px

# MLP 曲线
ax.plot(mlp_p, mlp_a, "o-", color="#2A9D8F", lw=3, ms=8, label="MLP (parameter-aligned)")

# 切比雪夫 KAN（落在曲线上 = 参数量假象）
ax.scatter([1635941], [99.081], color="#E07A5F", s=260, marker="s", zorder=6)
ax.annotate("Chebyshev KAN\n(parameter illusion)", xy=(1635941, 99.081),
            xytext=(500000, 98.45), fontsize=14, color="#C0392B", fontweight="bold",
            arrowprops=dict(arrowstyle="->", color="#C0392B", lw=2.5))

# B-spline KAN（跳出曲线上方 = 真实优势）
ax.scatter([2453344], [99.758], color="#7A5195", s=260, marker="D", zorder=6)
ax.annotate("B-spline KAN\n(genuine in-domain advantage)", xy=(2453344, 99.758),
            xytext=(2600000, 99.15), fontsize=14, color="#1B4965", fontweight="bold",
            arrowprops=dict(arrowstyle="->", color="#1B4965", lw=2.5))

ax.set_xscale("log")
ax.set_xlabel("Parameter budget (log scale)", fontsize=14)
ax.set_ylabel("Test accuracy (%) on LC25000", fontsize=14)
ax.set_ylim(98.0, 100.2)
ax.set_title("KAN classification head: the performance gain is determined by the basis function, not the architecture",
             fontsize=16, fontweight="bold", pad=12)
ax.tick_params(labelsize=12)
ax.grid(True, alpha=0.3, which="both")

fig.tight_layout()
fig.savefig(os.path.join(OUT, "graphical_abstract.png"), dpi=150, bbox_inches="tight")
plt.close(fig)
print("graphical_abstract.png 已生成（约 1992px 宽）")

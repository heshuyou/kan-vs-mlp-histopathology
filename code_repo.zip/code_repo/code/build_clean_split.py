# -*- coding: utf-8 -*-
"""
数据清洗（只读原图，产出新划分文件，不删除任何原图）：
  1. LC25000 (jpg/)：MD5 精确去重（1280 张冗余），保留每哈希一张；
     按 5 类前缀分层 80/20 划分，哈希保证 train/val 零内容泄漏。
  2. CRC-VAL-HE-7K：9 类分层 80/20 划分（本身 0 重复）。
产出：train_clean.txt / val_clean.txt / train_crc.txt / val_crc.txt（路径 + 标签）
用法：conda activate gpt2 && python build_clean_split.py
"""
import os
import hashlib
import glob
from collections import defaultdict, Counter

import numpy as np

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
JPG = os.path.join(BASE, "jpg")
CRC = os.path.join(BASE, "CRC-VAL-HE-7K")

# LC25000 前缀 → 标签（0=结肠腺癌 1=结肠良性 2=肺腺癌 3=肺良性 4=肺鳞癌）
LC_PREFIX = [("colon_aca", 0), ("colonn", 1), ("lungaca", 2), ("lungn", 3), ("lungscc", 4)]
# CRC-VAL-HE-7K 类别 → 标签
CRC_CLASSES = ["ADI", "BACK", "DEB", "LYM", "MUC", "MUS", "NORM", "STR", "TUM"]

SEED = 42
VAL_FRAC = 0.2


def md5(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        for c in iter(lambda: f.read(65536), b""):
            h.update(c)
    return h.hexdigest()


def lc_label(path):
    name = os.path.basename(path).lower()
    for pref, lab in LC_PREFIX:
        if name.startswith(pref):
            return lab
    raise ValueError(f"未知前缀: {name}")


def write_list(path, pairs):
    """pairs: [(相对路径, 标签)]，相对 BASE。"""
    with open(path, "w", encoding="utf-8") as f:
        for rel, lab in pairs:
            f.write(f"{rel} {lab}\n")


def verify_no_leak(tr_pairs, va_pairs):
    tr_h = {md5(os.path.join(BASE, p)) for p, _ in tr_pairs}
    va_h = {md5(os.path.join(BASE, p)) for p, _ in va_pairs}
    return len(tr_h & va_h)


def main():
    # ---------- LC25000 ----------
    print("=== LC25000 去重 ===")
    all_p = sorted(glob.glob(os.path.join(JPG, "*.jpeg")))
    by_hash = defaultdict(list)
    for p in all_p:
        by_hash[md5(p)].append(p)
    n_raw = len(all_p)
    n_unique = len(by_hash)
    print(f"原始 {n_raw} 张，唯一哈希 {n_unique} 张，冗余 {n_raw - n_unique} 张")

    # 每个哈希保留一张（排序取第一个，确定性）
    unique = [sorted(v)[0] for v in by_hash.values()]

    # 分层 80/20
    rng = np.random.default_rng(SEED)
    by_class = defaultdict(list)
    for p in unique:
        by_class[lc_label(p)].append(p)
    tr_pairs, va_pairs = [], []
    for lab in sorted(by_class):
        ps = sorted(by_class[lab])
        rng.shuffle(ps)
        n_va = int(round(len(ps) * VAL_FRAC))
        for p in ps[n_va:]:
            tr_pairs.append((os.path.relpath(p, BASE).replace("\\", "/"), lab))
        for p in ps[:n_va]:
            va_pairs.append((os.path.relpath(p, BASE).replace("\\", "/"), lab))
        print(f"  类别 {lab}: {len(ps)} 张 → train {len(ps)-n_va} / val {n_va}")

    leak = verify_no_leak(tr_pairs, va_pairs)
    assert leak == 0, f"仍存在泄漏 {leak} 张！"
    tr_path = os.path.join(BASE, "train_clean.txt")
    va_path = os.path.join(BASE, "val_clean.txt")
    write_list(tr_path, tr_pairs)
    write_list(va_path, va_pairs)
    print(f"LC25000 清洗后：train {len(tr_pairs)} / val {len(va_pairs)}，泄漏 {leak}（应 0）")
    print(f"  写出 {os.path.basename(tr_path)} / {os.path.basename(va_path)}")

    # ---------- CRC-VAL-HE-7K ----------
    print("\n=== CRC-VAL-HE-7K 分层划分 ===")
    crc_tr, crc_va = [], []
    for lab, cls in enumerate(CRC_CLASSES):
        d = os.path.join(CRC, cls)
        ps = sorted(glob.glob(os.path.join(d, "*")))
        rng.shuffle(ps)
        n_va = int(round(len(ps) * VAL_FRAC))
        for p in ps[n_va:]:
            crc_tr.append((os.path.relpath(p, BASE).replace("\\", "/"), lab))
        for p in ps[:n_va]:
            crc_va.append((os.path.relpath(p, BASE).replace("\\", "/"), lab))
        print(f"  {cls}: {len(ps)} 张 → train {len(ps)-n_va} / val {n_va}")
    tr_crc = os.path.join(BASE, "train_crc.txt")
    va_crc = os.path.join(BASE, "val_crc.txt")
    write_list(tr_crc, crc_tr)
    write_list(va_crc, crc_va)
    print(f"CRC 划分：train {len(crc_tr)} / val {len(crc_va)}")
    print(f"  写出 {os.path.basename(tr_crc)} / {os.path.basename(va_crc)}")


if __name__ == "__main__":
    main()

# -*- coding: utf-8 -*-
"""
实验 B：KAN 正则化消融（堵"你没调 KAN 专属正则"质疑）。
在切比雪夫 KAN 系数上加 L1 正则（KAN 文献常用的稀疏化 trick），
λ ∈ {0, 1e-5, 1e-4, 1e-3}，10 种子，报告最优 KAN 并对比参数对齐宽 MLP。

用法：conda activate gpt2 && python kan_regularization.py --seeds 10
"""
import os
import json
import argparse
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader

from baselines import KANBlock, KANLayer

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FEATS = os.path.join(BASE, "KAN", "lc25000_feats_resnet50.npz")
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
N_CLS = 5
DEFAULT_SEEDS = [42, 123, 2024, 7, 99, 100, 200, 300, 400, 500]


def set_seed(seed):
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def n_params(m):
    return sum(p.numel() for p in m.parameters())


def build_kan_head(d_in, n_cls=N_CLS):
    return nn.Sequential(
        KANBlock(d_in, 128, 5, 0.2), KANBlock(128, 64, 5, 0.2),
        KANBlock(64, 32, 5, 0.2), KANLayer(32, n_cls, 5, 0.0),
    )


def build_mlp_matched(d_in, target, n_cls=N_CLS):
    best_H, best_diff = None, None
    for H in range(64, 2049, 4):
        p = 2 * H * H + (d_in + n_cls + 2) * H + n_cls
        diff = abs(p - target)
        if best_diff is None or diff < best_diff:
            best_H, best_diff = H, diff
    H = best_H
    return nn.Sequential(
        nn.Linear(d_in, H), nn.ReLU(), nn.Dropout(0.2),
        nn.Linear(H, H), nn.ReLU(), nn.Dropout(0.2),
        nn.Linear(H, H), nn.ReLU(), nn.Dropout(0.2), nn.Linear(H, n_cls),
    ), H


def train_head(head, Xtr, Ytr, Xva, Yva, l1_lambda=0.0, epochs=15, batch_size=512):
    head = head.to(DEVICE)
    tr = torch.utils.data.TensorDataset(torch.from_numpy(Xtr), torch.from_numpy(Ytr))
    va = torch.utils.data.TensorDataset(torch.from_numpy(Xva), torch.from_numpy(Yva))
    tr_dl = DataLoader(tr, batch_size=batch_size, shuffle=True)
    va_dl = DataLoader(va, batch_size=batch_size)
    opt = optim.AdamW(head.parameters(), lr=1e-3, weight_decay=1e-4)
    sched = optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs)
    crit = nn.CrossEntropyLoss(label_smoothing=0.1)
    best_acc, best_state = 0.0, None
    for _ in range(epochs):
        head.train()
        for xb, yb in tr_dl:
            xb, yb = xb.to(DEVICE), yb.to(DEVICE)
            opt.zero_grad()
            loss = crit(head(xb), yb)
            if l1_lambda > 0:
                l1 = sum(m.coefficients.abs().sum() for m in head.modules() if isinstance(m, KANLayer))
                loss = loss + l1_lambda * l1
            loss.backward()
            opt.step()
        sched.step()
        head.eval()
        corr, tot = 0, 0
        with torch.no_grad():
            for xb, yb in va_dl:
                xb, yb = xb.to(DEVICE), yb.to(DEVICE)
                corr += (head(xb).argmax(1) == yb).sum().item()
                tot += yb.size(0)
        acc = corr / tot
        if acc > best_acc:
            best_acc = acc
            best_state = {k: v.clone() for k, v in head.state_dict().items()}
    head.load_state_dict(best_state)
    return best_acc * 100


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, default=10)
    args = ap.parse_args()

    d = np.load(FEATS)
    Xtr, Ytr, Xva, Yva = d["Xtr"].astype(np.float32), d["Ytr"], d["Xva"].astype(np.float32), d["Yva"]
    dim = Xtr.shape[1]
    seeds = DEFAULT_SEEDS[:args.seeds]
    print(f"train {Xtr.shape} | val {Xva.shape} | 特征维 {dim}")

    kan = build_kan_head(dim)
    mm, H = build_mlp_matched(dim, n_params(kan))
    print(f"KAN 参数量 {n_params(kan):,} | 参数对齐宽 MLP(H={H}) {n_params(mm):,}")

    l1_list = [0.0, 1e-5, 1e-4, 1e-3]
    partial = os.path.join(BASE, "KAN", "kan_reg_partial.json")
    res = {f"l1_{l}": [] for l in l1_list}
    if os.path.exists(partial):
        with open(partial, encoding="utf-8") as f:
            res = json.load(f)

    for l1 in l1_list:
        key = f"l1_{l1}"
        for i, seed in enumerate(seeds):
            if len(res[key]) > i:
                continue
            set_seed(seed)
            acc = train_head(build_kan_head(dim), Xtr, Ytr, Xva, Yva, l1_lambda=l1)
            res[key].append(acc)
            print(f"  L1={l1:g} seed {seed:>4d}: KAN {acc:6.3f}%", flush=True)
            with open(partial, "w", encoding="utf-8") as f:
                json.dump(res, f)

    print("\n================ 正则化消融 ================")
    for l1 in l1_list:
        a = np.array(res[f"l1_{l1}"])
        print(f"L1={l1:g}: KAN {a.mean():.3f}% ± {a.std(ddof=1):.3f}%")
    # 最优 KAN 对比宽 MLP
    best_key = max(l1_list, key=lambda l: np.mean(res[f"l1_{l}"]))
    best = np.array(res[f"l1_{best_key}"])
    print(f"\n最优 KAN（L1={best_key:g}）：{best.mean():.3f}% ± {best.std(ddof=1):.3f}%")
    print(f"参照 参数对齐宽 MLP：99.291% ± 0.054%（20 种子，主实验）")

    out = {"l1_list": l1_list, "res": res}
    with open(os.path.join(BASE, "KAN", "kan_regularization_result.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print("结果已保存 kan_regularization_result.json")


if __name__ == "__main__":
    main()

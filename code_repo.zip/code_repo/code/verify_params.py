# -*- coding: utf-8 -*-
"""
核对两类 KAN 分类头的参数量（逐层），确认总数与论文一致。
用法：conda activate gpt2 && python verify_params.py
"""
import torch
from baselines import KANBlock, KANLayer
from bspline_kan_experiment import BsplineKANLayer, BsplineKANBlock


def build_cheb(d_in=2048, n_cls=5):
    return torch.nn.Sequential(
        KANBlock(d_in, 128, 5, 0.2), KANBlock(128, 64, 5, 0.2),
        KANBlock(64, 32, 5, 0.2), KANLayer(32, n_cls, 5, 0.0),
    )


def build_bspline(d_in=2048, n_cls=5):
    return torch.nn.Sequential(
        BsplineKANBlock(d_in, 128, 5, 3, 0.2), BsplineKANBlock(128, 64, 5, 3, 0.2),
        BsplineKANBlock(64, 32, 5, 3, 0.2), BsplineKANLayer(32, n_cls, 5, 3),
    )


def print_layers(name, head):
    print(f"\n=== {name} ===")
    total = 0
    for i, block in enumerate(head.children()):
        p = sum(x.numel() for x in block.parameters())  # 含 nn.Parameter
        print(f"  block {i} ({type(block).__name__}): {p:,}")
        total += p
    print(f"  >>> 总参数: {total:,}")
    return total


def main():
    t1 = print_layers("Chebyshev KAN (degree=5)", build_cheb())
    t2 = print_layers("B-spline KAN (grid=5, order=3)", build_bspline())
    print(f"\nChebyshev {t1:,} vs 论文 1,635,941 -> {'一致' if t1 == 1635941 else '不一致'}")
    print(f"B-spline {t2:,} vs 论文 2,453,344 -> {'一致' if t2 == 2453344 else '不一致'}")


if __name__ == "__main__":
    main()

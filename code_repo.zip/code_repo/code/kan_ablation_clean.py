# -*- coding: utf-8 -*-
"""
KAN 变体消融（清洗后 ResNet50 缓存特征上训头）：
  1) 切比雪夫阶数 degree ∈ {3,5,8}（深度固定 3 层）
  2) 头深度 depth ∈ {1,2,3}（degree 固定 5），同时对比同深度 MLP
参照：参数对齐宽 MLP（99.29%）。每个配置 10 种子，报 mean±std。

用法：conda activate gpt2 && python kan_ablation_clean.py --seeds 10
"""
import os
import json
import argparse
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader

from baselines import KANBlock, KANLayer

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FEATS = os.path.join(BASE, "KAN", "lc25000_feats_resnet50.npz")
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
N_CLS = 5
DEFAULT_SEEDS = [42, 123, 2024, 7, 99, 100, 200, 300, 400, 500]


def set_seed(seed):
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def n_params(m):
    return sum(p.numel() for p in m.parameters())


def build_kan_head(degree, depth, d_in):
    if depth == 1:
        return nn.Sequential(KANBlock(d_in, 64, degree, 0.2), KANLayer(64, N_CLS, degree, 0.0))
    if depth == 2:
        return nn.Sequential(
            KANBlock(d_in, 64, degree, 0.2), KANBlock(64, 32, degree, 0.2),
            KANLayer(32, N_CLS, degree, 0.0))
    return nn.Sequential(
        KANBlock(d_in, 128, degree, 0.2), KANBlock(128, 64, degree, 0.2),
        KANBlock(64, 32, degree, 0.2), KANLayer(32, N_CLS, degree, 0.0))


def build_mlp_head(depth, d_in):
    if depth == 1:
        return nn.Sequential(nn.Linear(d_in, 64), nn.ReLU(), nn.Dropout(0.2), nn.Linear(64, N_CLS))
    if depth == 2:
        return nn.Sequential(
            nn.Linear(d_in, 64), nn.ReLU(), nn.Dropout(0.2),
            nn.Linear(64, 32), nn.ReLU(), nn.Dropout(0.2), nn.Linear(32, N_CLS))
    return nn.Sequential(
        nn.Linear(d_in, 128), nn.ReLU(), nn.Dropout(0.2),
        nn.Linear(128, 64), nn.ReLU(), nn.Dropout(0.2),
        nn.Linear(64, 32), nn.ReLU(), nn.Dropout(0.2), nn.Linear(32, N_CLS))


def build_mlp_matched(d_in, target):
    best_H, best_diff = None, None
    for H in range(64, 2049, 4):
        p = 2 * H * H + (d_in + N_CLS + 2) * H + N_CLS
        diff = abs(p - target)
        if best_diff is None or diff < best_diff:
            best_H, best_diff = H, diff
    H = best_H
    return nn.Sequential(
        nn.Linear(d_in, H), nn.ReLU(), nn.Dropout(0.2),
        nn.Linear(H, H), nn.ReLU(), nn.Dropout(0.2),
        nn.Linear(H, H), nn.ReLU(), nn.Dropout(0.2), nn.Linear(H, N_CLS)), H


def train_head(head, Xtr, Ytr, Xva, Yva, epochs=15, batch_size=512):
    head = head.to(DEVICE)
    tr = torch.utils.data.TensorDataset(torch.from_numpy(Xtr), torch.from_numpy(Ytr))
    va = torch.utils.data.TensorDataset(torch.from_numpy(Xva), torch.from_numpy(Yva))
    tr_dl = DataLoader(tr, batch_size=batch_size, shuffle=True)
    va_dl = DataLoader(va, batch_size=batch_size)
    opt = optim.AdamW(head.parameters(), lr=1e-3, weight_decay=1e-4)
    sched = optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs)
    crit = nn.CrossEntropyLoss(label_smoothing=0.1)
    best_acc, best_state = 0.0, None
    for _ in range(epochs):
        head.train()
        for xb, yb in tr_dl:
            xb, yb = xb.to(DEVICE), yb.to(DEVICE)
            opt.zero_grad()
            loss = crit(head(xb), yb)
            loss.backward()
            opt.step()
        sched.step()
        head.eval()
        corr, tot = 0, 0
        with torch.no_grad():
            for xb, yb in va_dl:
                xb, yb = xb.to(DEVICE), yb.to(DEVICE)
                corr += (head(xb).argmax(1) == yb).sum().item()
                tot += yb.size(0)
        acc = corr / tot
        if acc > best_acc:
            best_acc = acc
            best_state = {k: v.clone() for k, v in head.state_dict().items()}
    head.load_state_dict(best_state)
    return best_acc * 100


def run_seeds(builder, seeds, Xtr, Ytr, Xva, Yva, batch_size=512):
    accs = []
    for seed in seeds:
        set_seed(seed)
        accs.append(train_head(builder(), Xtr, Ytr, Xva, Yva, batch_size=batch_size))
    return np.array(accs)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, default=10)
    args = ap.parse_args()

    d = np.load(FEATS)
    Xtr, Ytr, Xva, Yva = d["Xtr"].astype(np.float32), d["Ytr"], d["Xva"].astype(np.float32), d["Yva"]
    dim = Xtr.shape[1]
    seeds = DEFAULT_SEEDS[:args.seeds]
    print(f"train {Xtr.shape} | val {Xva.shape} | 特征维 {dim}")

    partial = os.path.join(BASE, "KAN", "kan_ablation_partial.json")
    results = {}
    if os.path.exists(partial):
        with open(partial, encoding="utf-8") as f:
            results = json.load(f)

    # 参照：参数对齐宽 MLP
    kan3 = build_kan_head(5, 3, dim)
    mm, H = build_mlp_matched(dim, n_params(kan3))
    print(f"KAN(depth3,deg5) 参数量 {n_params(kan3):,} | 参数对齐宽 MLP(H={H}) {n_params(mm):,}")

    # 消融 1：degree
    print("\n=== 消融 1：切比雪夫阶数 degree（深度固定 3 层）===")
    for deg in [3, 5, 8]:
        key = f"degree_{deg}"
        if key in results:
            continue
        bs = 128 if deg == 8 else 512  # degree=8 系数张量过大，减小 batch 防 OOM
        accs = run_seeds(lambda: build_kan_head(deg, 3, dim), seeds, Xtr, Ytr, Xva, Yva, batch_size=bs)
        results[key] = {"params": n_params(build_kan_head(deg, 3, dim)), "accs": accs.tolist()}
        print(f"  degree={deg}: KAN {accs.mean():.3f}% ± {accs.std(ddof=1):.3f}% "
              f"（{results[key]['params']:,} 参数）", flush=True)
        with open(partial, "w", encoding="utf-8") as f:
            json.dump(results, f)

    # 消融 2：depth
    print("\n=== 消融 2：头深度 depth（degree 固定 5）===")
    for dep in [1, 2, 3]:
        key = f"depth_{dep}"
        if key in results:
            continue
        kaccs = run_seeds(lambda: build_kan_head(5, dep, dim), seeds, Xtr, Ytr, Xva, Yva)
        maccs = run_seeds(lambda: build_mlp_head(dep, dim), seeds, Xtr, Ytr, Xva, Yva)
        results[key] = {"kan_params": n_params(build_kan_head(5, dep, dim)),
                        "mlp_params": n_params(build_mlp_head(dep, dim)),
                        "kan_accs": kaccs.tolist(), "mlp_accs": maccs.tolist()}
        print(f"  depth={dep}: KAN {kaccs.mean():.3f}% ± {kaccs.std(ddof=1):.3f}% | "
              f"同深度MLP {maccs.mean():.3f}% ± {maccs.std(ddof=1):.3f}%", flush=True)
        with open(partial, "w", encoding="utf-8") as f:
            json.dump(results, f)

    out = os.path.join(BASE, "KAN", "kan_ablation_result.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print(f"\n结果已保存 {out}")


if __name__ == "__main__":
    main()

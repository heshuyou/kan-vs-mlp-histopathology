# -*- coding: utf-8 -*-
"""
计算 708 宽 MLP（B-spline 对齐，2.46M）在 CRC 九类任务上的 macro-F1（20 种子）。
训练协议与 bspline_kan_extra.py 完全一致（AdamW lr=1e-3、余弦退火、15 epoch、accuracy 早停）。
用法：conda activate gpt2 && python compute_macro_f1.py
"""
import os
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader

from bspline_kan_experiment import (build_mlp_matched, build_bspline_kan_head,
                                    set_seed, n_params, DEFAULT_SEEDS)

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CRC_FEATS = os.path.join(BASE, "KAN", "crc9_resnet50_feats.npz")
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
N_CLS = 9


def macro_f1(preds, tgts):
    fs = []
    for c in range(N_CLS):
        tp = int(((preds == c) & (tgts == c)).sum())
        fp = int(((preds == c) & (tgts != c)).sum())
        fn = int(((preds != c) & (tgts == c)).sum())
        p = tp / (tp + fp) if tp + fp > 0 else 0.0
        r = tp / (tp + fn) if tp + fn > 0 else 0.0
        fs.append(2 * p * r / (p + r) if p + r > 0 else 0.0)
    return float(np.mean(fs))


def train(head, Xtr, Ytr, Xva, Yva, epochs=15, batch_size=512):
    head = head.to(DEVICE)
    tr = torch.utils.data.TensorDataset(torch.from_numpy(Xtr), torch.from_numpy(Ytr))
    va = torch.utils.data.TensorDataset(torch.from_numpy(Xva), torch.from_numpy(Yva))
    tr_dl = DataLoader(tr, batch_size=batch_size, shuffle=True)
    va_dl = DataLoader(va, batch_size=batch_size)
    opt = optim.AdamW(head.parameters(), lr=1e-3, weight_decay=1e-4)
    sched = optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs)
    crit = nn.CrossEntropyLoss(label_smoothing=0.1)
    best_acc, best_state = 0.0, None
    for _ in range(epochs):
        head.train()
        for xb, yb in tr_dl:
            xb, yb = xb.to(DEVICE), yb.to(DEVICE)
            opt.zero_grad()
            loss = crit(head(xb), yb)
            loss.backward()
            opt.step()
        sched.step()
        head.eval()
        corr, tot = 0, 0
        with torch.no_grad():
            for xb, yb in va_dl:
                xb, yb = xb.to(DEVICE), yb.to(DEVICE)
                corr += (head(xb).argmax(1) == yb).sum().item()
                tot += yb.size(0)
        acc = corr / tot
        if acc > best_acc:
            best_acc = acc
            best_state = {k: v.clone() for k, v in head.state_dict().items()}
    head.load_state_dict(best_state)
    head.eval()
    preds, tgts = [], []
    with torch.no_grad():
        for xb, yb in va_dl:
            xb = xb.to(DEVICE)
            preds.append(head(xb).argmax(1).cpu().numpy())
            tgts.append(yb.numpy())
    preds = np.concatenate(preds)
    tgts = np.concatenate(tgts)
    return (preds == tgts).mean() * 100, macro_f1(preds, tgts)


def main():
    d = np.load(CRC_FEATS)
    Xtr, Ytr = d["Xtr"].astype(np.float32), d["Ytr"]
    Xva, Yva = d["Xva"].astype(np.float32), d["Yva"]
    dim = Xtr.shape[1]
    bkan = build_bspline_kan_head(dim, n_cls=N_CLS)
    mm, H = build_mlp_matched(dim, n_params(bkan), n_cls=N_CLS)
    print(f"B-spline KAN {n_params(bkan):,} | 708-MLP(H={H}) {n_params(mm):,}", flush=True)

    accs, f1s = [], []
    for seed in DEFAULT_SEEDS[:20]:
        set_seed(seed)
        acc, f1 = train(build_mlp_matched(dim, n_params(bkan), n_cls=N_CLS)[0],
                        Xtr, Ytr, Xva, Yva)
        accs.append(acc)
        f1s.append(f1)
        print(f"  seed {seed:>4d}: acc {acc:.3f}% | macro-F1 {f1:.4f}", flush=True)

    accs = np.array(accs)
    f1s = np.array(f1s)
    print(f"\n708-MLP (20 种子): acc {accs.mean():.3f}% ± {accs.std(ddof=1):.3f}% | "
          f"macro-F1 {f1s.mean():.4f} ± {f1s.std(ddof=1):.4f}", flush=True)


if __name__ == "__main__":
    main()

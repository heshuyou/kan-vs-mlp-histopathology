# -*- coding: utf-8 -*-
"""
生成论文 5 张核心图（英文标签，匹配英文版）：
  fig1_data_cleaning.png  数据清洗与泄漏移除流程图（3.1）
  fig4_param_sweep.png    参数扫描曲线（4.4，含 B-spline KAN 点）
  fig2_grouped_bar.png    多组实验准确率+误差棒（4.1/4.2/4.3）
  fig3_boxplot.png        20 种子准确率箱线图（稳定性）
  fig5_latency.png        推理时延 vs 参数量散点（4.7）

用法：conda activate gpt2 && python gen_figures5.py
"""
import os
import glob
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KAN = os.path.join(BASE, "KAN")
OUT = os.path.join(BASE, "paper_figures")
os.makedirs(OUT, exist_ok=True)

plt.rcParams["font.sans-serif"] = ["Arial", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False


def fig1_data_cleaning():
    fig, ax = plt.subplots(figsize=(15, 6))
    ax.axis("off")
    ax.set_xlim(0, 15)
    ax.set_ylim(0, 6.5)

    C_EDGE = "#1F4E79"   # 深蓝箭头
    C_DISC = "#C0392B"   # 丢弃红

    H = 2.2        # 统一矩形高度
    Y = 4.5        # 统一中心 y
    Y0 = Y - H / 2  # 底边 y = 3.4

    def rbox(x, w, fc, title, title_size=10.5):
        ax.add_patch(FancyBboxPatch((x, Y0), w, H, boxstyle="round,pad=0.05,rounding_size=0.12",
                                    fc=fc, ec="none"))
        ax.text(x + w / 2, Y0 + H - 0.32, title, ha="center", va="center",
                fontsize=title_size, fontweight="bold", color="#222222")

    def txt(x, y, s, **kw):
        kw.setdefault("fontsize", 7.5)
        kw.setdefault("color", "#444444")
        ax.text(x, y, s, ha="center", va="center", **kw)

    def arrow(x1, y1, x2, y2, dashed=False, color=C_EDGE):
        ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                    arrowprops=dict(arrowstyle="-|>", color=color, lw=1.5,
                                    linestyle=(0, (4, 3)) if dashed else "-",
                                    mutation_scale=13))

    # 1. Raw LC25000（5 个真实类别缩略图，居中一行）
    rbox(0.3, 2.3, "#F2F2F2", "Raw LC25000")
    classes = ["colon_aca", "colonn", "lungaca", "lungn", "lungscc"]
    for i, cls in enumerate(classes):
        fs = sorted(glob.glob(os.path.join(BASE, "jpg", cls + "*.jpeg")))
        if not fs:
            continue
        img = plt.imread(fs[0])
        x = 0.60 + i * 0.36
        ax.imshow(img, extent=[x, x + 0.32, 4.12, 4.44], zorder=5, aspect="auto")
    ax.text(1.45, Y0 + 0.18, "25,000 images · 5 classes", ha="center", va="center",
            fontsize=7.5, color="#444444")

    # 2. MD5 dedup（浅绿 + 分叉标注）
    rbox(3.2, 2.8, "#E8F5E9", "MD5 exact deduplication", title_size=9.5)
    txt(4.6, Y0 + 1.58, "Compute MD5 hash for every\nimage; detect identical copies")
    txt(4.6, Y0 + 0.78, "Unique: 23,720", fontsize=8, color="#1B5E20", fontweight="bold")
    txt(4.6, Y0 + 0.22, "Duplicates: 1,280 (5.1%)", color=C_DISC, fontweight="bold")

    # 3. Leakage inspection（浅黄）
    rbox(6.7, 2.3, "#FFF8E1", "Leakage inspection")
    txt(7.85, Y0 + 1.58, "Check for inadvertent\ntrain-test leakage")
    txt(7.85, Y0 + 0.22, "420 leaked (8.4%)", color=C_DISC, fontweight="bold")

    # 4. Stratified split（柔和淡蓝 + 两个输出）
    rbox(9.6, 2.8, "#E3F2FD", "Stratified train-val split", title_size=9.5)
    txt(11.0, Y0 + 1.58, "Preserve class proportion;\nfixed random seeds")
    txt(10.25, Y0 + 0.55, "Train\n18,976", color="#0D47A1", fontweight="bold")
    txt(11.85, Y0 + 0.55, "Validation\n4,744", color="#0D47A1", fontweight="bold")

    # 5. Cleaned（右端汇总）
    rbox(13.0, 1.8, "#E8F5E9", "Cleaned LC25000", title_size=9)
    txt(13.9, Y0 + 1.45, "for KAN / MLP\nhead comparison")

    # Discarded 收纳框（下方）
    ax.add_patch(FancyBboxPatch((3.2, 0.9), 6.0, 0.95, boxstyle="round,pad=0.05,rounding_size=0.12",
                                fc="#FDECEA", ec="none"))
    ax.text(6.2, 1.375, "Discarded: 1,280 duplicates + 420 leaked samples",
            ha="center", va="center", fontsize=9, fontweight="bold", color="#222222")

    # 主流程实心箭头
    arrow(2.6, Y, 3.2, Y)
    arrow(6.0, Y, 6.7, Y)
    arrow(9.0, Y, 9.6, Y)
    arrow(12.4, Y, 13.0, Y)

    # 丢弃虚线箭头（引向下方 Discarded）
    arrow(4.6, Y0, 4.6, 1.85, dashed=True, color=C_DISC)
    arrow(7.85, Y0, 7.85, 1.85, dashed=True, color=C_DISC)

    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "fig1_data_cleaning.pdf"), bbox_inches="tight")
    fig.savefig(os.path.join(OUT, "fig1_data_cleaning.png"), dpi=200, bbox_inches="tight")
    plt.close(fig)
    print("fig1_data_cleaning.png  done")


def fig4_param_sweep():
    mlp_p = np.array([139781, 295941, 657413, 1643141, 2758661, 4202501])
    mlp_a = np.array([98.463, 98.935, 99.113, 99.285, 99.344, 99.298])
    mlp_s = np.array([0.106, 0.072, 0.075, 0.060, 0.063, 0.087])
    cheb = (1635941, 99.081, 0.120)
    bspl = (2453344, 99.758, 0.036)

    fig, ax = plt.subplots(figsize=(7, 4.6))
    ax.errorbar(mlp_p, mlp_a, yerr=mlp_s, fmt="o-", color="#2A9D8F",
                capsize=3, lw=2, ms=5, label="MLP")
    ax.scatter([cheb[0]], [cheb[1]], color="#E07A5F", s=110, zorder=5,
               marker="s", label="Chebyshev KAN")
    ax.scatter([bspl[0]], [bspl[1]], color="#7A5195", s=110, zorder=5,
               marker="D", label="B-spline KAN")
    ax.errorbar([cheb[0]], [cheb[1]], yerr=[cheb[2]], fmt="none", ecolor="#E07A5F", capsize=3)
    ax.errorbar([bspl[0]], [bspl[1]], yerr=[bspl[2]], fmt="none", ecolor="#7A5195", capsize=3)

    # 辅助水平线：切比雪夫 KAN 等价于更小 MLP
    ax.axhline(cheb[1], color="#E07A5F", ls="--", lw=1, alpha=0.5)
    # 计算水平线与 MLP 曲线的交点（log 空间线性插值），箭头精确指到曲线上
    idx = int(np.where(mlp_a <= cheb[1])[0][-1])
    x1, y1 = mlp_p[idx], mlp_a[idx]
    x2, y2 = mlp_p[idx + 1], mlp_a[idx + 1]
    frac = (cheb[1] - y1) / (y2 - y1)
    x_cross = 10 ** (np.log10(x1) + frac * (np.log10(x2) - np.log10(x1)))
    ax.annotate(f"Chebyshev KAN ≈ {x_cross / 1e6:.2f}M MLP", xy=(x_cross, cheb[1]), xytext=(200000, 99.15),
                fontsize=8, color="#E07A5F", arrowprops=dict(arrowstyle="->", color="#E07A5F"))

    ax.set_xscale("log")
    ax.set_xlabel("Parameter count (log scale)")
    ax.set_ylabel("Test accuracy (%) on LC25000")
    ax.set_ylim(98.2, 100.0)
    ax.legend(loc="lower right", fontsize=9, framealpha=0.6, handlelength=1.2, borderpad=0.6, markerscale=0.5)
    ax.grid(True, alpha=0.3, which="both")
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "fig4_param_sweep.pdf"), bbox_inches="tight")
    fig.savefig(os.path.join(OUT, "fig4_param_sweep.png"), dpi=200, bbox_inches="tight")
    plt.close(fig)
    print("fig4_param_sweep.png  done")


def fig2_grouped_bar():
    fig, axes = plt.subplots(1, 3, figsize=(13, 4.2))

    # (a) LC25000 (ResNet50)
    heads = ["Narrow\nMLP", "Chebyshev\nKAN", "B-spline\nKAN", "Wide MLP\n(aligned)"]
    vals = [98.507, 99.065, 99.758, 99.291]
    errs = [0.091, 0.175, 0.036, 0.054]
    colors = ["#2A9D8F", "#E07A5F", "#7A5195", "#457B9D"]
    axes[0].bar(heads, vals, yerr=errs, capsize=3, color=colors, alpha=0.85)
    axes[0].set_title("(a) LC25000 (ResNet50)", fontsize=10)
    axes[0].set_ylabel("Accuracy (%)")
    axes[0].set_ylim(97.8, 100.0)
    axes[0].grid(True, alpha=0.3, axis="y")

    # (b) CRC 9-class
    heads2 = ["Narrow\nMLP", "Chebyshev\nKAN", "B-spline\nKAN", "Wide MLP\n(aligned)"]
    vals2 = [96.720, 97.820, 98.203, 98.071]
    errs2 = [0.471, 0.171, 0.108, 0.068]
    axes[1].bar(heads2, vals2, yerr=errs2, capsize=3, color=colors, alpha=0.85)
    axes[1].set_title("(b) CRC-VAL-HE-7K (9-class)", fontsize=10)
    axes[1].set_ylim(95.5, 98.6)
    axes[1].grid(True, alpha=0.3, axis="y")

    # (c) cross-domain
    vals3 = [70.49, 69.75, 70.40, 70.47]
    errs3 = [0.71, 3.03, 2.75, 0.42]
    axes[2].bar(heads2, vals3, yerr=errs3, capsize=3, color=colors, alpha=0.85)
    axes[2].set_title("(c) LC25000→CRC (cross-domain)", fontsize=10)
    axes[2].set_ylim(62, 78)
    axes[2].grid(True, alpha=0.3, axis="y")

    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "fig2_grouped_bar.pdf"), bbox_inches="tight")
    fig.savefig(os.path.join(OUT, "fig2_grouped_bar.png"), dpi=200, bbox_inches="tight")
    plt.close(fig)
    print("fig2_grouped_bar.png  done")


def fig3_boxplot():
    # 读取 20 种子原始数据
    def load20(path, key=None):
        d = json.load(open(path, encoding="utf-8"))
        if key:
            d = d[key]
        return d

    cross = json.load(open(os.path.join(KAN, "colon_gen_result.json"), encoding="utf-8"))["acc"]
    crc = json.load(open(os.path.join(KAN, "crc9_result.json"), encoding="utf-8"))["acc"]
    lc = json.load(open(os.path.join(KAN, "clean_lc25000_resnet50_partial.json"), encoding="utf-8"))

    fig, axes = plt.subplots(1, 3, figsize=(13, 4.2), sharey=False)
    labels = ["Narrow MLP", "Cheb. KAN", "Wide MLP"]
    colors = ["#2A9D8F", "#E07A5F", "#457B9D"]

    def draw(ax, data, title, ylim):
        boxes = [data["mlp"], data["kan"], data["mlp_matched"]]
        bp = ax.boxplot(boxes, labels=labels, patch_artist=True, showmeans=True,
                        showfliers=True, widths=0.5)
        for patch, c in zip(bp["boxes"], colors):
            patch.set_facecolor(c); patch.set_alpha(0.7)
        for m in bp["means"]:
            m.set_markerfacecolor("black"); m.set_markeredgecolor("black")
        ax.set_title(title, fontsize=10)
        ax.set_ylim(ylim)
        ax.grid(True, alpha=0.3, axis="y")
        ax.tick_params(axis="x", labelsize=8)

    draw(axes[0], lc, "(a) LC25000 (20 seeds)", (97.8, 100.0))
    draw(axes[1], crc, "(b) CRC-VAL-HE-7K (20 seeds)", (95.5, 98.6))
    draw(axes[2], cross, "(c) Cross-domain (20 seeds)", (62, 80))

    fig.text(0.5, 0.01, "Box plots of test accuracy across 20 random seeds, showing the training instability of KAN heads (note the large spread of Chebyshev KAN in cross-domain).",
             ha="center", fontsize=8.5, style="italic")
    fig.tight_layout(rect=[0, 0.04, 1, 1])
    fig.savefig(os.path.join(OUT, "fig3_boxplot.pdf"), bbox_inches="tight")
    fig.savefig(os.path.join(OUT, "fig3_boxplot.png"), dpi=200, bbox_inches="tight")
    plt.close(fig)
    print("fig3_boxplot.png  done")


def fig5_latency():
    fig, ax = plt.subplots(figsize=(6.5, 4.4))
    # (params, latency_ms, label, color, marker)
    pts = [
        (272773, 0.37, "Narrow MLP (0.27M)", "#2A9D8F", "o"),
        (1643141, 0.31, "Wide MLP (1.64M)", "#457B9D", "o"),
        (1635941, 2.61, "Chebyshev KAN (1.64M)", "#E07A5F", "s"),
        (2453344, 2.60, "B-spline KAN (2.45M)", "#7A5195", "D"),
    ]
    for p, lat, lab, c, mk in pts:
        ax.scatter([p], [lat], s=90, color=c, marker=mk, zorder=5, label=lab)
    # 虚线连接同参数量的宽 MLP 与 KAN
    ax.plot([1643141, 1635941], [0.31, 2.61], ls=":", color="0.4", lw=1.2)
    ax.annotate("~8.4× latency", xy=(1600000, 1.5), fontsize=9, color="C0392B".replace("C0392B", "#C0392B"), fontweight="bold")

    ax.set_xscale("log")
    ax.set_xlabel("Parameter count (log scale)")
    ax.set_ylabel("Inference latency (ms, batch=1)")
    ax.legend(loc="best", fontsize=6.5, framealpha=0.7, markerscale=0.7)
    ax.grid(True, alpha=0.3, which="both")
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "fig5_latency.pdf"), bbox_inches="tight")
    fig.savefig(os.path.join(OUT, "fig5_latency.png"), dpi=200, bbox_inches="tight")
    plt.close(fig)
    print("fig5_latency.png  done")



def fig6_confusion():
    d = json.load(open(os.path.join(KAN, "error_analysis_clean.json"), encoding="utf-8"))
    cm = np.array(d["confusion_matrix"])
    labels = ["Colon ACA", "Colon benign", "Lung ACA", "Lung benign", "Lung SCC"]
    fig, ax = plt.subplots(figsize=(5.5, 4.8))
    im = ax.imshow(cm, cmap="Blues")
    ax.set_xticks(range(5)); ax.set_xticklabels(labels, rotation=30, ha="right", fontsize=9)
    ax.set_yticks(range(5)); ax.set_yticklabels(labels, fontsize=9)
    ax.set_xlabel("Predicted class")
    ax.set_ylabel("True class")
    ax.set_title("Confusion matrix of the Chebyshev KAN head")
    for i in range(5):
        for j in range(5):
            ax.text(j, i, str(cm[i, j]), ha="center", va="center",
                    color="white" if cm[i, j] > cm.max() / 2 else "black", fontsize=9)
    fig.colorbar(im, ax=ax)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "fig6_confusion.pdf"), bbox_inches="tight")
    fig.savefig(os.path.join(OUT, "fig6_confusion.png"), dpi=200, bbox_inches="tight")
    plt.close(fig)
    print("fig6_confusion done")


if __name__ == "__main__":
    fig1_data_cleaning()
    fig4_param_sweep()
    fig2_grouped_bar()
    fig3_boxplot()
    fig5_latency()
    fig6_confusion()
    print("\n全部 5 张图已生成到 paper_figures/")

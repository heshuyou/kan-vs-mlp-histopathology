# -*- coding: utf-8 -*-
"""
数据审计（只读，不训练）：找出 LC25000 (jpg/) 与 CRC-VAL-HE-7K 的数据问题。
检查项：
  1. 各类图像数量、文件大小、图像尺寸分布
  2. 精确重复（MD5 相同）—— 数据集内部 / 跨数据集 / train-val 泄漏
  3. train_list.txt vs val_list.txt 是否存在同名或同哈希泄漏
用法：conda activate gpt2 && python data_audit.py
"""
import os
import hashlib
import glob
from collections import Counter, defaultdict
from PIL import Image

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
JPG = os.path.join(BASE, "jpg")
CRC = os.path.join(BASE, "CRC-VAL-HE-7K")
TRAIN_LIST = os.path.join(BASE, "train_list.txt")
VAL_LIST = os.path.join(BASE, "val_list.txt")

CRC_CLASSES = ['ADI', 'BACK', 'DEB', 'LYM', 'MUC', 'MUS', 'NORM', 'STR', 'TUM']


def md5(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def scan(root, exts=('.jpeg', '.jpg', '.png', '.tif')):
    """返回 {路径: md5}，仅文件名匹配 exts。"""
    out = {}
    for p in glob.glob(os.path.join(root, "**", "*"), recursive=True):
        if os.path.isfile(p) and p.lower().endswith(exts):
            out[p] = None
    return out


def fill(paths):
    for p in paths:
        paths[p] = md5(p)
    return paths


def report_dups(name, paths):
    by_hash = defaultdict(list)
    for p, h in paths.items():
        by_hash[h].append(p)
    dups = {h: v for h, v in by_hash.items() if len(v) > 1}
    n_dup_imgs = sum(len(v) - 1 for v in dups.values())
    print(f"[{name}] 总 {len(paths)} 张，唯一哈希 {len(by_hash)}，重复组 {len(dups)}，多余重复图像 {n_dup_imgs}")
    return by_hash


def main():
    print("=== 1. 扫描 jpg/ (LC25000) ===")
    jpg_paths = fill(scan(JPG))
    jpg_hash = report_dups("LC25000", jpg_paths)

    # LC25000 类别分布（按文件名前缀）
    prefix_cnt = Counter()
    for p in jpg_paths:
        name = os.path.basename(p).lower()
        for pref in ('colon_aca', 'colonn', 'lungaca', 'lungn', 'lungscc'):
            if name.startswith(pref):
                prefix_cnt[pref] += 1
                break
        else:
            prefix_cnt['OTHER'] += 1
    print("   LC25000 前缀分布:", dict(prefix_cnt))

    print("\n=== 2. 扫描 CRC-VAL-HE-7K ===")
    crc_paths = fill(scan(CRC))
    crc_hash = report_dups("CRC-VAL-HE-7K", crc_paths)
    for c in CRC_CLASSES:
        n = sum(1 for p in crc_paths if os.path.sep + c + os.path.sep in p)
        print(f"   {c}: {n}")

    print("\n=== 3. 跨数据集重叠（LC25000 ∩ CRC-VAL-HE-7K，按 MD5）===")
    jpg_hset = set(jpg_hash.keys())
    crc_hset = set(crc_hash.keys())
    overlap = jpg_hset & crc_hset
    print(f"   精确重叠哈希数: {len(overlap)}")
    if overlap:
        # 打印重叠图像在 LC25000 里的前缀分布
        jp = defaultdict(list)
        for h in overlap:
            for p in jpg_hash[h]:
                jp[os.path.basename(p)[:20]].append(p)
        # 统计重叠的 LC25000 图像类别
        oc = Counter()
        for h in overlap:
            for p in jpg_hash[h]:
                name = os.path.basename(p).lower()
                for pref in ('colon_aca', 'colonn', 'lungaca', 'lungn', 'lungscc'):
                    if name.startswith(pref):
                        oc[pref] += 1
                        break
        print("   重叠的 LC25000 图像类别分布:", dict(oc))
        # 重叠的 CRC 类别分布
        cc = Counter()
        for h in overlap:
            for p in crc_hash[h]:
                for c in CRC_CLASSES:
                    if os.path.sep + c + os.path.sep in p:
                        cc[c] += 1
        print("   重叠的 CRC 类别分布:", dict(cc))

    print("\n=== 4. train_list vs val_list 泄漏 ===")
    def load_list(fp):
        names = []
        with open(fp, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    names.append(line.split()[0])
        return names
    tr = load_list(TRAIN_LIST)
    va = load_list(VAL_LIST)
    tr_set, va_set = set(tr), set(va)
    print(f"   train {len(tr)} 行（去重 {len(tr_set)}），val {len(va)} 行（去重 {len(va_set)}）")
    print(f"   train 与 val 路径交集（同名文件）: {len(tr_set & va_set)}")
    # 按哈希查 train/val 是否共享内容
    tr_h = {md5(os.path.join(BASE, p)) for p in tr_set if os.path.exists(os.path.join(BASE, p))}
    va_h = {md5(os.path.join(BASE, p)) for p in va_set if os.path.exists(os.path.join(BASE, p))}
    print(f"   train 唯一哈希 {len(tr_h)}，val 唯一哈希 {len(va_h)}，哈希交集（内容泄漏）: {len(tr_h & va_h)}")

    print("\n=== 5. 图像尺寸分布（抽样每类前 20 张）===")
    dims = Counter()
    samples = []
    for p in list(jpg_paths)[:400]:
        samples.append(p)
    for p in list(crc_paths)[:200]:
        samples.append(p)
    for p in samples:
        try:
            with Image.open(p) as im:
                dims[im.size] += 1
        except Exception as e:
            print(f"   读取失败 {p}: {e}")
    print("   尺寸分布:", dict(dims))

    print("\n=== 6. 文件大小异常（0 字节或极小）===")
    bad = [p for p in list(jpg_paths) + list(crc_paths) if os.path.getsize(p) < 1024]
    print(f"   <1KB 的文件数: {len(bad)}")
    for p in bad[:20]:
        print("     ", p, os.path.getsize(p))


if __name__ == "__main__":
    main()

# -*- coding: utf-8 -*-
"""
参数扫描（在缓存 ResNet50 特征上训 MLP 头，不同宽度）：
  证明"参数量假象"——MLP 精度随参数量上升、最终反超 KAN。
  三层等宽 MLP，宽度 H ∈ {64,128,256,528,768,1024}，参数量从 0.14M 到 4.2M，
  与 KAN 头（1.64M）对照。每个配置 10 种子，报 mean±std。

用法：conda activate gpt2 && python param_sweep.py --seeds 10
"""
import os
import json
import argparse
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader

from baselines import KANBlock, KANLayer

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FEATS = os.path.join(BASE, "KAN", "lc25000_feats_resnet50.npz")
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
N_CLS = 5
DEFAULT_SEEDS = [42, 123, 2024, 7, 99, 100, 200, 300, 400, 500]

# 等宽 MLP 宽度 → 参数量（3 层，d_in=2048）
SWEEP_H = [64, 128, 256, 528, 768, 1024]


def set_seed(seed):
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def n_params(m):
    return sum(p.numel() for p in m.parameters())


def build_mlp_width(d_in, H, n_cls=N_CLS):
    return nn.Sequential(
        nn.Linear(d_in, H), nn.ReLU(), nn.Dropout(0.2),
        nn.Linear(H, H), nn.ReLU(), nn.Dropout(0.2),
        nn.Linear(H, H), nn.ReLU(), nn.Dropout(0.2), nn.Linear(H, n_cls),
    )


def build_kan_head(d_in, n_cls=N_CLS):
    return nn.Sequential(
        KANBlock(d_in, 128, 5, 0.2), KANBlock(128, 64, 5, 0.2),
        KANBlock(64, 32, 5, 0.2), KANLayer(32, n_cls, 5, 0.0),
    )


def train_head(head, Xtr, Ytr, Xva, Yva, epochs=15, batch_size=512):
    head = head.to(DEVICE)
    tr = torch.utils.data.TensorDataset(torch.from_numpy(Xtr), torch.from_numpy(Ytr))
    va = torch.utils.data.TensorDataset(torch.from_numpy(Xva), torch.from_numpy(Yva))
    tr_dl = DataLoader(tr, batch_size=batch_size, shuffle=True)
    va_dl = DataLoader(va, batch_size=batch_size)
    opt = optim.AdamW(head.parameters(), lr=1e-3, weight_decay=1e-4)
    sched = optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs)
    crit = nn.CrossEntropyLoss(label_smoothing=0.1)
    best_acc, best_state = 0.0, None
    for _ in range(epochs):
        head.train()
        for xb, yb in tr_dl:
            xb, yb = xb.to(DEVICE), yb.to(DEVICE)
            opt.zero_grad()
            loss = crit(head(xb), yb)
            loss.backward()
            opt.step()
        sched.step()
        head.eval()
        corr, tot = 0, 0
        with torch.no_grad():
            for xb, yb in va_dl:
                xb, yb = xb.to(DEVICE), yb.to(DEVICE)
                corr += (head(xb).argmax(1) == yb).sum().item()
                tot += yb.size(0)
        acc = corr / tot
        if acc > best_acc:
            best_acc = acc
            best_state = {k: v.clone() for k, v in head.state_dict().items()}
    head.load_state_dict(best_state)
    return best_acc * 100


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, default=10)
    args = ap.parse_args()

    d = np.load(FEATS)
    Xtr, Ytr, Xva, Yva = d["Xtr"].astype(np.float32), d["Ytr"], d["Xva"].astype(np.float32), d["Yva"]
    dim = Xtr.shape[1]
    print(f"train {Xtr.shape} | val {Xva.shape} | 特征维 {dim}")

    seeds = DEFAULT_SEEDS[:args.seeds]
    results = {"sweep": {}, "kan": {}}
    partial = os.path.join(BASE, "KAN", "param_sweep_partial.json")
    if os.path.exists(partial):
        with open(partial, encoding="utf-8") as f:
            results = json.load(f)
        print("加载断点（部分结果）")

    # KAN 参照
    if not results["kan"]:
        kan_accs = []
        for seed in seeds:
            set_seed(seed)
            kan_accs.append(train_head(build_kan_head(dim), Xtr, Ytr, Xva, Yva))
            print(f"  KAN seed {seed:>4d}: {kan_accs[-1]:.3f}%", flush=True)
        results["kan"] = {"params": n_params(build_kan_head(dim)), "accs": kan_accs}
        with open(partial, "w", encoding="utf-8") as f:
            json.dump(results, f)

    # MLP 宽度扫描
    for H in SWEEP_H:
        key = str(H)
        if key in results["sweep"] and len(results["sweep"][key]["accs"]) >= args.seeds:
            continue
        mlp = build_mlp_width(dim, H)
        p = n_params(mlp)
        accs = []
        for seed in seeds:
            set_seed(seed)
            accs.append(train_head(build_mlp_width(dim, H), Xtr, Ytr, Xva, Yva))
            print(f"  MLP H={H:>4d} ({p:,} 参数) seed {seed:>4d}: {accs[-1]:.3f}%", flush=True)
        results["sweep"][key] = {"params": p, "accs": accs}
        with open(partial, "w", encoding="utf-8") as f:
            json.dump(results, f)

    # 汇总
    print("\n================ 参数扫描汇总 ================")
    print(f"{'配置':<16}{'参数量':>12}{'准确率':>18}")
    kan = results["kan"]
    print(f"{'KAN':<16}{kan['params']:>12,}{np.mean(kan['accs']):>14.3f}% ± {np.std(kan['accs'], ddof=1):.3f}%")
    for H in SWEEP_H:
        r = results["sweep"][str(H)]
        a = np.array(r["accs"])
        print(f"{'MLP H='+str(H):<16}{r['params']:>12,}{a.mean():>14.3f}% ± {a.std(ddof=1):.3f}%")

    out = os.path.join(BASE, "KAN", "param_sweep_result.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print(f"\n结果已保存 {out}")


if __name__ == "__main__":
    main()
